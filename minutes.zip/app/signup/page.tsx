import { redirect } from 'next/navigation';
import { getUser } from '@/lib/auth';
import { normalizeDomain } from '@/lib/signup';
import SignupForm from './SignupForm';

export const metadata = { title: '회원가입' };
export const dynamic = 'force-dynamic';

export default async function SignupPage() {
  if (await getUser()) redirect('/');
  const open = !!process.env.SIGNUP_CODE;
  return (
    <div className="narrow">
      <h1>회원가입</h1>
      {open ? (
        <SignupForm domain={normalizeDomain(process.env.SIGNUP_EMAIL_DOMAIN)} />
      ) : (
        <p className="empty">현재 회원가입을 받지 않고 있습니다. 관리자에게 문의해 주세요.</p>
      )}
    </div>
  );
}
